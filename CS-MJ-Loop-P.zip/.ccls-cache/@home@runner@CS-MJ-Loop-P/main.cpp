#include <iostream>

using namespace std;

int main() {
  
  for (int j = 10; j <= 1000; j += 10){
    cout << j << endl;
  }

for (int n = 1; n <= 17; n++) {

  cout << "David" << endl;
  
}
  
for (int t = 10; t>= 1; t--)
  
  cout << t << endl;

    for (int k = 5; k <= 50; k+=5) {
        cout << k << endl;

    }
  
return 0;
}